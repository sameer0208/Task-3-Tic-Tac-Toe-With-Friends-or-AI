document.addEventListener("DOMContentLoaded", function() {
    const cells = document.querySelectorAll(".cell");
    const playFriendsButton = document.getElementById("play-friends");
    const playAIButton = document.getElementById("play-ai");
    const modeSelection = document.getElementById("mode-selection");
    const board = document.querySelector(".board");
    const modal = document.getElementById("modal");
    const modalMessage = document.getElementById("modal-message");
    const aiMessage = document.getElementById("ai-message");

    let currentPlayer = "X";
    let gameEnded = false;
    let isPlayingWithAI = false;

    // Audio setup
    const clapAudio = new Audio("clap_audio.mp3");
    clapAudio.loop = false;

    const drawAudio = new Audio("draw_audio.mp3");
    drawAudio.loop = false;

    const clickAudio = new Audio("mouse_click.mp3");
    clickAudio.loop = false;

    // Event listeners for mode selection buttons
    playFriendsButton.addEventListener("click", function() {
        modeSelection.style.display = "none";
        board.style.display = "grid"; // Display the board
        isPlayingWithAI = false;
        startGame();
    });

    playAIButton.addEventListener("click", function() {
        modeSelection.style.display = "none";
        board.style.display = "grid"; // Display the board
        isPlayingWithAI = true;
        startGame();
    });

    function startGame() {
        cells.forEach(cell => {
            cell.textContent = "";
            cell.addEventListener("click", handleCellClick);
        });

        if (isPlayingWithAI && currentPlayer === "O") {
            // AI makes the first move
            showAIMessage(true);
            makeAIMove();
        }
    }

    function handleCellClick() {
        if (this.textContent === "" && !gameEnded) {
            this.textContent = currentPlayer;
            clickAudio.play();
            if (checkWin()) {
                announceWinner(currentPlayer);
            } else if (checkDraw()) {
                announceDraw();
            } else {
                currentPlayer = currentPlayer === "X" ? "O" : "X";
                if (isPlayingWithAI && currentPlayer === "O" && !gameEnded) {
                    showAIMessage(true);
                    // Delay AI move slightly for better user experience
                    setTimeout(makeAIMove, 500);
                }
            }
        }
    }

    function makeAIMove() {
        let bestScore = -Infinity;
        let bestMove;
        for (let i = 0; i < cells.length; i++) {
            if (cells[i].textContent === "") {
                cells[i].textContent = "O";
                clickAudio.play();
                const score = minimax(cells, 0, false);
                cells[i].textContent = "";
                if (score > bestScore) {
                    bestScore = score;
                    bestMove = i;
                }
            }
        }
        cells[bestMove].textContent = "O";

        if (checkWin()) {
            announceWinner("O");
        } else if (checkDraw()) {
            announceDraw();
        }
        currentPlayer = "X";
        showAIMessage(false);
    }

    function minimax(cells, depth, isMaximizing) {
        if (checkWinForPlayer("O")) {
            return 10 - depth;
        } else if (checkWinForPlayer("X")) {
            return depth - 10;
        } else if (checkDraw()) {
            return 0;
        }

        if (isMaximizing) {
            let bestScore = -Infinity;
            for (let i = 0; i < cells.length; i++) {
                if (cells[i].textContent === "") {
                    cells[i].textContent = "O";
                    const score = minimax(cells, depth + 1, false);
                    cells[i].textContent = "";
                    bestScore = Math.max(bestScore, score);
                }
            }
            return bestScore;
        } else {
            let bestScore = Infinity;
            for (let i = 0; i < cells.length; i++) {
                if (cells[i].textContent === "") {
                    cells[i].textContent = "X";
                    const score = minimax(cells, depth + 1, true);
                    cells[i].textContent = "";
                    bestScore = Math.min(bestScore, score);
                }
            }
            return bestScore;
        }
    }

    function checkWinForPlayer(player) {
        const winConditions = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
            [0, 4, 8], [2, 4, 6]             // diagonals
        ];
        return winConditions.some(condition => {
            const [a, b, c] = condition;
            return cells[a].textContent === player &&
                   cells[a].textContent === cells[b].textContent &&
                   cells[a].textContent === cells[c].textContent;
        });
    }

    function checkWin() {
        return checkWinForPlayer("X") || checkWinForPlayer("O");
    }

    function checkDraw() {
        return [...cells].every(cell => cell.textContent !== "");
    }

    function announceWinner(winner) {
        gameEnded = true;
        if (isPlayingWithAI) {
            if (winner === "O") {
                showModal("Ohh you lose, fight again 😔!");
                drawAudio.play(); // Play the audio
        setTimeout(() => {
            drawAudio.pause(); // Pause after 5 seconds
            drawAudio.currentTime = 0; // Reset audio to start
        }, 5000);
            } else {
                showModal(`Congratulations 🎉 You WON!`);
                clapAudio.play(); // Play the audio
                setTimeout(() => {
                    clapAudio.pause(); // Pause after 5 seconds
                    clapAudio.currentTime = 0; // Reset audio to start
                }, 5000);
            }
        } else {
            showModal(`Congratulations 🎉 ${winner} wins!`);
            clapAudio.play(); // Play the audio
                setTimeout(() => {
                    clapAudio.pause(); // Pause after 5 seconds
                    clapAudio.currentTime = 0; // Reset audio to start
                }, 5000);
        }
        setTimeout(resetGame, 5000); // Reset game after 5 seconds
    }

    function announceDraw() {
        gameEnded = true;
        showModal("It's a draw 😯!");
        drawAudio.play(); // Play the audio
        setTimeout(() => {
            drawAudio.pause(); // Pause after 5 seconds
            drawAudio.currentTime = 0; // Reset audio to start
        }, 5000);
        setTimeout(resetGame, 5000); // Reset game after 5 seconds
    }

    function showModal(message) {
        modalMessage.textContent = message;
        modal.style.display = "flex";
        setTimeout(() => {
            modal.style.display = "none";
        }, 5000);
    }

    function resetGame() {
        cells.forEach(cell => {
            cell.textContent = "";
        });
        currentPlayer = "X";
        gameEnded = false;
        modeSelection.style.display = "block"; // Show mode selection buttons
        board.style.display = "none"; // Hide the board
    }

    function showAIMessage(show) {
        aiMessage.style.display = show ? "block" : "none";
    }
});
